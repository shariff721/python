print("Hello World")

name = "Sharif Muyanja"
print("Hello", name)
print("Hello " + "Sharif Muyanja")

name = 721
print("Hello", name)
print("Hello " + str(name))    #NINJA BONUS

fave_food1 = "Rice"
fave_food2 = "Chicken"
print(f"I love to eat {fave_food1} and {fave_food2}.")
print("I love to eat {} and {}.".format(fave_food1,fave_food2))

# NINJA BOUNS

print("I love to eat %s and %s." %(fave_food1,fave_food2))